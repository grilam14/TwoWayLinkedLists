#include <iostream>
#include "CommunicationNetwork.h"
#include <fstream>
#include <sstream>

using namespace std;

int main(int argc, char* argv[]){

CommunicationNetwork c;

bool run = true;


while(run == true){

    string command="0";

    cout<<"======Main Menu======"<<endl;
    cout<<"1. Build Network"<<endl;
    cout<<"2. Print Network Path"<<endl;
    cout<<"3. Transmit Message Coast-To-Coast-To-Coast"<<endl;
    cout<<"4. Add City"<<endl;
    cout<<"5. Delete City"<<endl;
    cout<<"6. Clear Network"<<endl;
    cout<<"7. Quit"<<endl;



    getline(cin,command);

    if(command=="1"){
        c.buildNetwork();
    }
    else if(command=="2"){
        c.printNetwork();
    }
    else if(command=="3"){

        char *filename = argv[1];
        c.transmitMsg(filename);
    }
    else if(command=="4"){

        string cityNew, cityPrevious;


        cout << "Enter a city name: "<<endl;;
        getline(cin,cityNew);

        cout << "Enter a previous city name: "<<endl;
        getline(cin,cityPrevious);

        c.addCity(cityPrevious, cityNew);

    }
    else if(command=="5"){
        string cityToDelete;

        cout << "Enter a city name: "<<endl;;
        getline(cin,cityToDelete);

        c.deleteCity(cityToDelete);
    }
    else if(command=="6"){

        c.~CommunicationNetwork();

    }
    else if(command=="7"){
        cout << "Goodbye!" << endl;
        run = false;
        c.~CommunicationNetwork();
    }

    else if(command=="8"){
        c.printReverse();

    }


}

return 0;
}
