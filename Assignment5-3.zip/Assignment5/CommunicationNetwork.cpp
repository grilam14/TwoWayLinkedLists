#include <iostream>
#include "CommunicationNetwork.h"
#include <fstream>
#include <sstream>

using namespace std;

CommunicationNetwork::CommunicationNetwork(){
    head = new City;
    tail = new City;
}

CommunicationNetwork:: ~CommunicationNetwork(){
    City* temp = new City;
    temp=head;

    while(temp!=NULL){
        head=temp->next;
        cout<<"deleting "<<temp->cityName<<endl;
        delete temp;
        temp=head;
    }
    head=tail=NULL;

}
void CommunicationNetwork:: deleteCity(std::string cityToDelete){

    City *temp= new City;
    temp=head;
    if(temp->cityName==cityToDelete){//delete head
        City *next=new City;
        next=temp->next;
        head=next;
        delete temp;
        temp=next;
        next->previous=NULL;
    }

    while(temp->next!=NULL){
        if(temp->cityName==cityToDelete){
            City *next=new City;
            City *previous=new City;

            next=temp->next;
            previous=temp->previous;
            next->previous=previous;
            previous->next=next;
            delete temp;
            temp=next;
        }

        else{
            temp=temp->next;
        }
    }
    if(temp->cityName==cityToDelete){
        City *previous=new City;
        previous=temp->previous;
        tail=previous;
        tail->next= NULL;
        delete temp;
        }

}

void CommunicationNetwork:: deleteNetwork(){

}

void CommunicationNetwork:: addCity(string previousCity, string newCity){

    City *temp = new City;
    temp=head;//

    if(previousCity=="First"){
            City *temp2= new City;
            temp2->cityName=newCity;

            temp->previous=temp2;
            temp2->next=temp;
            head=temp2;
            temp=temp->next;
        }

    while(temp->next!=NULL){

        if(temp->cityName==previousCity){//if city names match

            City *temp2 = new City;//create new node for added city

            temp2->cityName=newCity;
            temp2->next=temp->next;//temp2 takes temp's next

            temp2->previous=temp;//new node adds temp as previous

            temp->next=temp2;//temp next is now temp2


            City *rightBound=new City;//far right bound of this group of nodes
            rightBound=temp2->next;
            rightBound->previous=temp2;//sets previous to newly added temp

            temp=temp->next;

        }else{
            temp=temp->next;//loop moves on

        }

    }
    //temp is Boston at this point
    if(temp->cityName==previousCity){
            City *temp2=new City;
            temp2->cityName=newCity;

            temp->next=temp2;
            temp2->previous=temp;
            tail=temp2;
        }

}

void CommunicationNetwork:: buildNetwork(){

    string citylist [] = {"Los Angeles", "Phoenix", "Denver", "Dallas", "St. Louis", "Chicago", "Atlanta", "Washington, D.C.", "New York", "Boston"};
    City *temp = new City;

    //City *head = new City; //add this line back to get the code to work. I cannot figure out how use the original private variable to work

    for(int i=0;i<10;i++){
        City *temp2 = new City;
        if(head->cityName==""){//if head is empty
            head->cityName=citylist[i];//add the first city to head
            temp=head;//sets temp to head

        }
        else{//the rest of the struct
            temp2->cityName=citylist[i];//temp2 is the next city
            temp->next=temp2;//the first round through, head->next is the new city
            temp2->previous=temp;
            temp=temp2;
        }
    }

    tail=temp;

    temp=head;
    cout<<"===CURRENT PATH==="<<endl;
    cout<<"NULL <- ";
    while(temp != NULL){
        cout<<temp->cityName;
        if(temp->next != NULL){
            cout<<" <-> ";
        }
        temp=temp->next;
    }
    cout<<" -> NULL"<<endl;
    cout<<"=================="<<endl;

}

void CommunicationNetwork:: transmitMsg(char * filename){
    string word;

    ifstream data (filename);

    while(getline(data,word,'\n')){
        //send word down linked list
        stringstream ss;
        ss<<word;
        while (getline(ss,word,' ')){
        City *temp = new City;

        temp=head;

        while(temp->next != NULL){
            temp->message=word;
            cout<<temp->cityName<<" received "<<temp->message<<endl;
            temp->message="";
            temp=temp->next;

        }

        while(temp != NULL){
            temp->message=word;
            cout<<temp->cityName<<" received "<<temp->message<<endl;
            temp->message="";
            temp=temp->previous;

        }


    }
    }
}

void CommunicationNetwork:: printNetwork(){
    City *temp = new City;
    temp=head;

    cout<<"===CURRENT PATH==="<<endl;
    if(head==NULL){
        cout<<"NULL"<<endl;
    }
    else{
    cout<<"NULL <- ";
    while(temp != NULL){
        cout<<temp->cityName;
        if(temp->next != NULL){
            cout<<" <-> ";
        }
        temp=temp->next;
    }
    cout<<" -> NULL"<<endl;
    }
    cout<<"=================="<<endl;
}

void CommunicationNetwork:: printReverse(){



    City *temp = new City;
    temp=tail;
    cout<<"===CURRENT PATH==="<<endl;
    if(head==NULL){
        cout<<"NULL"<<endl;
    }
    else{
    cout<<"NULL <- ";
    while(temp != NULL){
        cout<<temp->cityName;
        if(temp->previous != NULL){
            cout<<" <-> ";
        }
        temp=temp->previous;
    }
    }
    cout<<" -> NULL"<<endl;
    cout<<"=================="<<endl;

}

